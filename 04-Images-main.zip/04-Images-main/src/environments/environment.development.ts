export const environment = {
  production: true,
  companyName: 'Gifst',
  companyName2: 'App',
  companySlogan: 'Maneja tus gifs',

  giphyApiKey: 'z95y66T1JfOasFTVolvK7izqwREvlqWv',
  giphyURL: 'https://api.giphy.com/v1'
};
